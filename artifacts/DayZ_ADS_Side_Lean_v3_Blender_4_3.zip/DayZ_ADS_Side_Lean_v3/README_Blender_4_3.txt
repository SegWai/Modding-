DAYZ ADS SIDE LEAN - Blender 4.3.2 compatible edition

Built and reopened in Blender 4.3.2. Opens in Solid view without a renderer.
Frame 1: character RIGHT lean. Frame 25: neutral ADS. Frame 49: LEFT lean.
Select Armature and enter Pose Mode to edit. Scrub the named timeline markers.

Original 114-bone rest skeleton, 7499 mesh vertices, face topology, UVs and
skin weights preserved from your supplied character. Original helper empties
are retained hidden. The schematic rifle is only an optional aiming guide.
The studio/render setup from the 5.1 version has been omitted.
Revised v3 follows the annotated stance: support foot reaches 58 cm off
center, opposite knee stays closer beneath the pelvis. Pelvis is lowered
11 cm for a planted, nearly extended side leg. Upper body lean stays 26
degrees and the raised right elbow stays at shoulder height. The head
moves toward the sight and turns slightly toward the right-eye ocular.
Weight placement is an artistic pose, not a physics simulation.
Aiming stays forward (-Y). This is a pose study, not a DayZ gameplay mod.
