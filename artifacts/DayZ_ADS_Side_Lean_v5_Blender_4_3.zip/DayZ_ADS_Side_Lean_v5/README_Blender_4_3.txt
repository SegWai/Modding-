DAYZ ADS SIDE LEAN - Blender 4.3.2 compatible edition

Built and reopened in Blender 4.3.2. Opens in Solid view without a renderer.
Frame 1: character RIGHT lean. Frame 25: neutral ADS. Frame 49: LEFT lean.
Select Armature and enter Pose Mode to edit. Scrub the named timeline markers.

Original 114-bone rest skeleton, 7499 mesh vertices, face topology, UVs and
skin weights preserved from your supplied character. Original helper empties
are retained hidden. The schematic rifle is only an optional aiming guide.
The studio/render setup from the 5.1 version has been omitted.
Revised v5: right palm faces inward onto the pistol grip; index finger
is posed at the schematic trigger; remaining fingers and thumb wrap the
grip. Left palm faces upward beneath the fore-end, with fingers curled
up the far side and thumb opposing them. Hand targets and arm bends
adjust to fit the grip. Torso, legs and upright head are retained from
v4. The rifle and trigger are schematic positioning guides only.
Aiming stays forward (-Y). This is a pose study, not a DayZ gameplay mod.
