MOVEMENTLAB - STATIONARY OWN-PLAYER EDITOR v1

Separate authoring test, based on v165 and the exact approved v161 preset.
Includes the narrow v166-v168 late-aim/grip corrections. Original tests are
unchanged. This test edits YOUR OWN PLAYER in first person, then displays the
same authored settings in third person. It has no first-person crouch pose
substitution and no camera-dependent editor bank. The original reference NPC
is still present and shares the settings; it is not the only edited character.

LAUNCH
Close DayZ, start Steam, double-click Launch-Mosin-Lean-Test.cmd in THIS folder.
Only this test's two PBO mods are loaded. No Workshop dependencies are needed.
The native AK74, SKS and Glock loadout is retained. Author standing, stationary,
with the AK74/another shouldered rifle RAISED. Crouch, prone, moving and lowered
poses are not the authoring scope. No native stance or player height is forced.
Game/data paths use the project's shared resolver. A bundled resolver is also
included so the runtime ZIP can run separately; it detects Steam libraries and
Documents/DayZ Projects or P:. DAYZ_GAME_PATH and DAYZ_DATA_PATH override them.
Optional standalone DayZ-Paths.local.json entries are Game and Data directories.

AUTHOR / INSPECT
1. Raise the AK74 and use your normal first-person perspective control. Start
   looking roughly forward/level; iron sights are optional. Keep the rifle up.
2. F6 opens weapon XYZ/rotation, muzzle and grip-preserving arm-direction/head
   controls. F7 opens body/joint XYZ position and pitch/yaw/roll controls.
3. Click Edit LEFT or Edit RIGHT. While the panel is open with Hold selected
   lean ON, your own standing raised player holds that visual side, so you can
   release Q/E and use the mouse. The same selected side holds the reference NPC.
4. F7 dropdown or Previous/Next selects one of 60 joints: pelvis/spine, both neck
   joints, head, shoulders/upper arms/forearms/hands, legs/feet/toes, arm twist
   bones, and 32 finger/palm joints. Forearm controls move the elbow region;
   F6 arm controls change elbow bend direction while preserving cached reach.
5. Position uses centimetres in character/model axes (X right, Y up, Z forward).
   Rotation uses degrees. Parent edits carry descendants; ring-base edits also
   affect the finger descendants attached there. Slider steps are 0.1; +/-
   buttons use 0.5 cm / 1 degree. These are additive adjustments to this pose.
6. Hold RIGHT MOUSE for look/WASD navigation while a panel is open; release to
   resume sliders. Moving temporarily exits stationary authoring scope. Raising
   and firing are blocked while the panel owns input to prevent accidental shots.
7. F6/F7 or Esc closes the panel. Switch to third person with your usual view
   key, then hold Q/E to see that side on YOUR player. Reopen F6/F7 in either
   view to continue. Hold LeftAlt for your normal free-look inspection.
8. Save all in EITHER panel saves BOTH sides, weapon/arms/head and all 60 body
   joints together. Load all restores the combined save. Reset part/side means
   zero/reference offsets, not restoration of the shipped approved pose.

YOUR SEPARATE SAVE
Profiles/OwnPlayerEditor/MLOwnPlayerLeanPreset.json
Backup: MLOwnPlayerLeanPreset.json.bak, in the same folder.
The file auto-loads on the next launch of this test. Send that JSON after tuning.
It uses expanded schema 2; do not copy it over an older MLLeanPreset.json.
MLLeanPreset-Approved-v161.json is an unchanged reference copy, never the live save.
The initial 24 body parts and all weapon settings are EXACTLY the approved values;
the 36 added joints start at zero. None of your approved archives are modified.

LIMITS / NATIVE CHECK STILL NEEDED
The same editor controls and saved bank run in both views. Native aiming,
breathing, recoil and camera projection can still affect what you see; this is
not absolute head locking or a second independent first-person skeleton.
Direct F7 translations/rotations can distort a limb, move fingers through a gun
or separate grip contact. F6 is the constrained weapon/elbow tool. At large aim
angles native arm IK can constrain direct arm edits to keep contact. Start with
small edits and centred aim. No gun firing/reload/recoil animation is replaced.
Finger/twist offsets use graph nodes, not generic live bone-matrix writes.
Face animation, weapon/helper bones and separate reload/action clips are not
exposed. No new walking/jogging/prone pose authoring or full pistol support.

The v165 four single-evaluation left correction gates remain intact. Extra joints
use binary bypasses and cached control writes; this is not a measured FPS claim.
Native script compilation, UI focus, finger rendering, grip, ADS, view switching,
firing/recoil and performance require your in-game test. No game was run by the
builder. If there is an error, run Collect-Logs.cmd; it includes this test's logs,
the saved pose and the newest crash dump when at most 24 MB. Use one test at a time.

CHECK WITHOUT STARTING DAYZ
Launch-Mosin-Lean-Test.cmd -CheckOnly
