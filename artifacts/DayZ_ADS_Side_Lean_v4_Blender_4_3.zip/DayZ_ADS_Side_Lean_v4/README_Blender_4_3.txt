DAYZ ADS SIDE LEAN - Blender 4.3.2 compatible edition

Built and reopened in Blender 4.3.2. Opens in Solid view without a renderer.
Frame 1: character RIGHT lean. Frame 25: neutral ADS. Frame 49: LEFT lean.
Select Armature and enter Pose Mode to edit. Scrub the named timeline markers.

Original 114-bone rest skeleton, 7499 mesh vertices, face topology, UVs and
skin weights preserved from your supplied character. Original helper empties
are retained hidden. The schematic rifle is only an optional aiming guide.
The studio/render setup from the 5.1 version has been omitted.
Revised v4: leg shapes from v3 are exchanged by mirroring the stance
around the pelvis center. At frame49 the character RIGHT leg is the
wide side leg and the LEFT leg is the closer, bent leg. Pelvis, torso,
raised right elbow and hand targets are retained. Head is counter-banked
to stay upright, with its forward nod and sight-facing yaw retained.
This is an artistic pose study, not a physics simulation.
Aiming stays forward (-Y). This is a pose study, not a DayZ gameplay mod.
