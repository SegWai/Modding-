24 transparent PNG silhouette versions of the stance/speed chart, including the additional slow-aim level3.
Each named icon is320x320 RGBA. all_icons_transparent.png is the combined4x6 sheet.
Black silhouettes may look invisible in a black-background image viewer; place them on a light background to inspect.
Momentum symbols retain their amber locks. These are image assets, not a mod installer.
Transparent versions were prepared with the image editor from the approved chart; they are not pixel-identical cutouts of the blue-backed tiles.
