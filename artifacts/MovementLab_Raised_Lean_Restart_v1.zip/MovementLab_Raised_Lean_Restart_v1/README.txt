MOVEMENTLAB RAISED LEAN RESTART v1

Close DayZ, start Steam, and open Launch-Raised-Lean-Test.cmd. The separate
offline scene issues AK74 rifles and requires no Workshop dependencies.

Raise your rifle and use your normal Q/E lean controls while standing, then
strafe left and right at walk and jog speeds while holding either lean.
For each side, first hold a steady stationary lean while aiming forward and
level for about one second. Keep leaning as you move. The first steady move
in each direction and gait learns a reference. Repeat this for ADS if you
want to compare through sights. A new weapon needs fresh references.

The unclothed reference NPC stands in front of you. It carries an AK74 and
its fitted attachments. The native character model may show underwear.
After a roughly 14-second standing warmup it cycles through standing, walk
left/right, and jog left/right on Q, then the same sequence on E. Each slot
takes six seconds, including one second centred. It demonstrates in place.

One byte-identical approved v161 standing preset supplies every gait. The
moving graph uses its standing upper-body corrections, with a cached match
to the standing reference. Standing leg offsets fade out during movement.
Leg stride and vertical gait motion remain native, and native aim/grip can
alter the visible result. The graph targets the same upper-body pose at the
sampled reference. Individual gait frames can still differ.

This is a new graph resource using existing motion clips. The custom branch
is scoped to upright raised rifle lean at idle and lateral walk/jog. Other states
route through native locomotion. There are no editing panels in this test.

Offline graph, preset, PBO and ZIP checks passed. Native compilation, visual
match, grip, recoil, transitions and FPS need an in-game check. If the test
fails, use Collect-Logs.cmd. Launch-Raised-Lean-Test.cmd -CheckOnly verifies
paths and package checksums without starting the game.
