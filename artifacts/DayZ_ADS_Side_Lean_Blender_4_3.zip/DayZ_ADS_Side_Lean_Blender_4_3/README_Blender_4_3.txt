DAYZ ADS SIDE LEAN - Blender 4.3.2 compatible edition

Built and reopened in Blender 4.3.2. Opens in Solid view without a renderer.
Frame 1: character RIGHT lean. Frame 25: neutral ADS. Frame 49: LEFT lean.
Select Armature and enter Pose Mode to edit. Scrub the named timeline markers.

Original 114-bone rest skeleton, 7499 mesh vertices, face topology, UVs and
skin weights preserved from your supplied character. Original helper empties
are retained hidden. The schematic rifle is only an optional aiming guide.
The studio/render setup from the 5.1 version has been omitted.
Pelvis stays centered; opposite leg stays in its neutral aiming pose;
same-side foot steps outward 7 cm; upper body banks 17 degrees.
Aiming stays forward (-Y). This is a pose study, not a DayZ gameplay mod.
