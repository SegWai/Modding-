@echo off
setlocal EnableExtensions DisableDelayedExpansion
powershell.exe -NoProfile -NonInteractive -Command "if (Get-Process -Name DayZ_x64,DayZDiag_x64 -ErrorAction SilentlyContinue) { exit 1 }"
if errorlevel 1 (
    echo Close DayZ before building the missing animation PBO.
    pause
    exit /b 1
)
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Build-Missing-Clips.ps1"
if errorlevel 1 (
    echo Build failed. Keep the error text and send it for diagnosis.
    pause
    exit /b 1
)
echo Clips PBO ready. Run Launch-Prebuilt-PBO-Test.cmd in this test folder.
pause
