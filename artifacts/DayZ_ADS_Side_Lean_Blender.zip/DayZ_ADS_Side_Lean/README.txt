DAYZ ADS SIDE LEAN - Blender pose study

Open DayZ_ADS_Side_Lean.blend in Blender 5.1 or newer.
The file opens on the LEFT lean at frame 49.
Frame 1 = character RIGHT lean; frame 25 = neutral ADS; frame 49 = character LEFT lean.
Select Armature and enter Pose Mode to edit the poses.
Scrub the timeline markers to compare.

The pelvis stays centered. The opposite leg keeps the neutral pose.
The support foot steps 7 cm outward. The spine banks 17 degrees, with both
arms and the head following while the forward aim remains -Y.
The schematic rifle is an optional visual guide, not an original DayZ weapon.
Hide the PREVIEW ONLY collections for just the supplied character rig.
Original mesh geometry, rest skeleton, hierarchy and weights are preserved.
Preview materials and lighting are included; original materials remain in the file.

This is a Blender pose study for review, not an installed gameplay modification.
No DayZ animation export or native engine playtest is included.
