# Shared path resolver. Explicit arguments > environment > local config > detection.
$script:DayZRepositoryRoot = $PSScriptRoot
$script:DayZPathSettings = @{}
$settingsFile = Join-Path $script:DayZRepositoryRoot 'DayZ-Paths.local.json'
if (Test-Path -LiteralPath $settingsFile) {
    $settings = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
    foreach ($property in $settings.PSObject.Properties) { $script:DayZPathSettings[$property.Name] = [string]$property.Value }
}
function Resolve-DayZPath {
    param([ValidateSet('Game','Data','Tools')][string]$Kind, [string]$Override = '')
    $relative = @{ Game = 'DayZDiag_x64.exe'; Data = 'DZ\anims'; Tools = 'Bin\AddonBuilder\AddonBuilder.exe' }[$Kind]
    $envName = @{ Game = 'DAYZ_GAME_PATH'; Data = 'DAYZ_DATA_PATH'; Tools = 'DAYZ_TOOLS_PATH' }[$Kind]
    $preferred = $Override
    if (-not $preferred) { $preferred = [Environment]::GetEnvironmentVariable($envName) }
    if (-not $preferred -and $script:DayZPathSettings.ContainsKey($Kind)) { $preferred = $script:DayZPathSettings[$Kind] }
    if ($preferred) {
        $preferred = $preferred.Trim().Trim('"')
        if (-not (Test-Path -LiteralPath (Join-Path $preferred $relative))) { throw "Invalid $Kind path: $preferred (missing $relative). Update DayZ-Paths.local.json or $envName." }
        return (Get-Item -LiteralPath $preferred).FullName
    }
    $candidates = @()
    if ($Kind -eq 'Data') { $candidates += @((Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'DayZ Projects'), 'P:\') }
    else {
        $steamRoots = @()
        foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
            if (Test-Path $key) {
                try { $item = Get-ItemProperty $key -ErrorAction Stop } catch { continue }
                foreach ($name in @('SteamPath','InstallPath')) {
                    if ($item.PSObject.Properties[$name]) { $steamRoots += [string]$item.$name }
                }
            }
        }
        foreach ($steam in @($steamRoots)) {
            $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
            if (Test-Path -LiteralPath $vdf) {
                foreach ($match in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $steamRoots += $match.Groups[1].Value.Replace('\\','\') }
            }
        }
        $folder = if ($Kind -eq 'Game') { 'DayZ' } else { 'DayZ Tools' }
        foreach ($steam in $steamRoots) { $candidates += Join-Path $steam "steamapps\common\$folder" }
        foreach ($drive in Get-PSDrive -PSProvider FileSystem) { $candidates += Join-Path $drive.Root "SteamLibrary\steamapps\common\$folder" }
    }
    foreach ($candidate in $candidates | Select-Object -Unique) {
        if (Test-Path -LiteralPath (Join-Path $candidate $relative)) { return (Get-Item -LiteralPath $candidate).FullName }
    }
    throw "Cannot locate DayZ $Kind. Set $envName or $Kind in DayZ-Paths.local.json. Required: $relative"
}
