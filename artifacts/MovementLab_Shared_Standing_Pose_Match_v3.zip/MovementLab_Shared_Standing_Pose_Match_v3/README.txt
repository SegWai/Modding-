MOVEMENTLAB SHARED STANDING POSE MATCH v3

Raise the AK74 while standing and use Q/E. All four centre-to-side and
side-to-centre transitions use one eased lean amount. The standing graph
stays selected through centre. The movement guard still returns to native
locomotion on movement intent and waits for idle before re-entry.
First-person left sight following ramps in near centre and retains its
full weight at the established lean endpoint.

The 20-joint match remains cached during ordinary Q/E transitions. It
eases in after initial capture and fades out on release. Quick reversals
fade the previous side to zero before switching correction coefficients.
Keep the rifle forward and level for the initial capture. F6/F7 and X
continue to share the standing pose with the NPC.

The public ZIP starts from the approved default inside the PBO. To reuse
a save, copy MLSharedStandingLeanPreset.json to Profiles/SharedStandingMatchV3.
The local v3 folder copies the previous local v2 save into its own profile.

Launcher and offline transition checks are separate from native playback.
Test neutral to Q, Q to neutral, neutral to E, E to neutral and fast Q/E
reversals. Repeat the Shift movement exit and return to idle.
