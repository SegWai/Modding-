// One bare native reference actor. Only rifles are issued.
class MLSharedStandingLeanMission : MissionGameplay
{
 protected PlayerBase m_Reference;
 protected bool m_Started;
 override void OnInit()
 {
  super.OnInit();
  if (GetGame().IsMultiplayer() || m_Started)
   return;
  m_Started = true;
  GetGame().GetWorld().SetDate(2026, 6, 15, 12, 0);
  vector spawn = "4440 0 10240";
  spawn[1] = GetGame().SurfaceY(spawn[0], spawn[2]) + 0.2;
  PlayerBase player = PlayerBase.Cast(GetGame().CreatePlayer(null, "SurvivorM_Mirek", spawn, 0, "NONE"));
  if (!player)
   return;
  GetGame().SelectPlayer(null, player);
  player.SetOrientation("145 0 0");
  ClearGear(player);
  GiveBoots(player);
  GiveRifle(player);
  PrepareActor(player);
  vector spot = spawn + player.GetDirection() * 4;
  spot[1] = GetGame().SurfaceY(spot[0], spot[2]) + 0.2;
  m_Reference = PlayerBase.Cast(GetGame().CreatePlayer(null, "SurvivorM_Denis", spot, 0, "NONE"));
  if (!m_Reference)
   return;
  m_Reference.SetOrientation("325 0 0");
  ClearGear(m_Reference);
  GiveBoots(m_Reference);
  PrepareActor(m_Reference);
  if (!GiveRifle(m_Reference))
  {
   Print("[MLSHARED] reference rifle could not be created");
   return;
  }
  MLADSLeanSettings.DemoActor = m_Reference;
  m_Reference.MLADSLeanStartDemo();
 }
 protected void ClearGear(PlayerBase actor)
 {
  array<EntityAI> gear = new array<EntityAI>;
  actor.GetInventory().EnumerateInventory(InventoryTraversalType.PREORDER, gear);
  int index = gear.Count();
  while (index > 0)
  {
   index--;
   EntityAI inventoryItem = gear[index];
   if (inventoryItem && inventoryItem != actor)
    GetGame().ObjectDelete(inventoryItem);
  }
 }
 protected void GiveBoots(PlayerBase actor)
 {
  EntityAI boots = actor.GetInventory().CreateAttachment("CombatBoots_Black");
  if (!boots)
   Print("[MLSHARED] boots could not be equipped");
 }
 protected bool GiveRifle(PlayerBase actor)
 {
  Weapon_Base rifle = Weapon_Base.Cast(actor.GetHumanInventory().CreateInHands("AK74"));
  if (!rifle)
   return false;
  MLADSLeanRangeAmmo.EquipAK74(rifle);
  return true;
 }
 protected void PrepareActor(PlayerBase actor)
 {
  actor.SetAllowDamage(false);
  actor.GetStatWater().Set(actor.GetStatWater().GetMax());
  actor.GetStatEnergy().Set(actor.GetStatEnergy().GetMax());
 }
 override void OnMissionFinish()
 {
  PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
  if (player)
   player.MLSharedClearFreeze();
  MLSharedPreview.KeyDown = false;
  ML144State.Open = false;
  ML149State.Open = false;
  if (m_Reference)
  {
   m_Reference.MLADSLeanStopDemo();
   GetGame().ObjectDelete(m_Reference);
   m_Reference = null;
  }
  MLADSLeanSettings.DemoActor = null;
  super.OnMissionFinish();
 }
};
Mission CreateCustomMission(string path)
{
 return new MLSharedStandingLeanMission();
}
