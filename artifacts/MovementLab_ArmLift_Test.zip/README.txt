MovementLab: original arm-lift import test

Blender version: 4.3.2. No addon installation needed to play this BLEND file.
Expected animation: arms start by the sides; right arm rises and returns.
Duration: approximately 4 seconds, 30 fps. Root and feet stay still.

1. Extract this ZIP using Windows "Extract All".
2. Copy the TestAnimations folder into:
   D:\DayZProjects\MovementLabWorkbench
3. Open TestAnimations\MovementLab_ArmLift_Test.blend in Blender.
   Press Space to play. Stop with Space.
4. Restart DayZ Workbench using your configured desktop shortcut.
   Expand Game Root > MovementLabWorkbench > TestAnimations.
   Select the test animation resource.
5. Report whether an ANM resource appears/imports, or send the precise console
   error. The exact Workbench import action still needs local verification.

The TXA and ANM metadata should be in the same TestAnimations directory.
The metadata path is specific to this project's folder arrangement.

This bundle contains animation source, an editable reference rig, and import
metadata. It is NOT a packed mod and has not been tested inside DayZ.
Do not assign it to or save changes in the original player workspace yet.
The final walking animation and movement changes come after this pipeline test.

Checks completed in cloud Blender: export and parse; frame range; rig bone names;
finite transforms; normalized rotations; matching start/end; stationary feet;
hand rises; visual inspection of start and middle poses.
Windows Workbench compilation and in-game playback: pending.

See ASSET_NOTICES.txt for attribution and reference-asset terms.
