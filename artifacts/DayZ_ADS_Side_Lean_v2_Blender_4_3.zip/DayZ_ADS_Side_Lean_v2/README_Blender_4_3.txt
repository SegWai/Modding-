DAYZ ADS SIDE LEAN - Blender 4.3.2 compatible edition

Built and reopened in Blender 4.3.2. Opens in Solid view without a renderer.
Frame 1: character RIGHT lean. Frame 25: neutral ADS. Frame 49: LEFT lean.
Select Armature and enter Pose Mode to edit. Scrub the named timeline markers.

Original 114-bone rest skeleton, 7499 mesh vertices, face topology, UVs and
skin weights preserved from your supplied character. Original helper empties
are retained hidden. The schematic rifle is only an optional aiming guide.
The studio/render setup from the 5.1 version has been omitted.
Revised v2: right upper arm elevated 90 degrees from the torso down axis;
elbow at shoulder height in the torso frame. Upper body banks 26 degrees
with a straighter upper spine. Pelvis shifts 8 cm to the lean and lowers
9 cm. Support foot is 36 cm to the side. Head moves 5 cm forward and nods
6 degrees toward the sight. Weight support is a visual pose, not physics.
Aiming stays forward (-Y). This is a pose study, not a DayZ gameplay mod.
