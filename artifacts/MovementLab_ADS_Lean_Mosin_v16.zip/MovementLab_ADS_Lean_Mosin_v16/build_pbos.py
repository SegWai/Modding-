"""Build and independently verify the two small, uncompressed test PBOs.
Run with Python 3 from any working directory. Not needed to launch the supplied ZIP.
"""
from pathlib import Path
import hashlib,json,struct,subprocess,re,sys,zipfile
ROOT=Path(__file__).resolve().parent

def read_pbo(data):
 position=0
 def string():
  nonlocal position
  stop=data.index(b'\0',position);value=data[position:stop].decode('ascii');position=stop+1;return value
 assert string()==''
 assert struct.unpack_from('<5I',data,position)==(0x56657273,0,0,0,0);position+=20
 assert string()=='prefix';prefix=string();assert string()==''
 rows=[]
 while True:
  name=string();method,original,reserved,stamp,size=struct.unpack_from('<5I',data,position);position+=20
  assert (method,original,reserved,stamp)==(0,0,0,0)
  if not name:assert size==0;break
  rows.append((name,size))
 result={}
 for name,size in rows:
  assert name not in result;result[name]=data[position:position+size];assert len(result[name])==size;position+=size
 assert data[position:position+1]==b'\0'
 assert data[position+1:]==hashlib.sha1(data[:position]).digest()
 return prefix,result

def build(source,prefix,target):
 entries={p.relative_to(source).as_posix().replace('/','\\'):p.read_bytes() for p in source.rglob('*') if p.is_file()}
 assert entries and 'config.cpp' in entries
 header=b'\0'+struct.pack('<5I',0x56657273,0,0,0,0)+b'prefix\0'+prefix.encode()+b'\0\0'
 for name,payload in sorted(entries.items()):header+=name.encode('ascii')+b'\0'+struct.pack('<5I',0,0,0,0,len(payload))
 body=header+b'\0'+struct.pack('<5I',0,0,0,0,0)+b''.join(v for _,v in sorted(entries.items()))
 data=body+b'\0'+hashlib.sha1(body).digest()
 parsed_prefix,parsed=read_pbo(data);assert parsed_prefix==prefix and parsed==entries
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 return hashlib.sha256(data).hexdigest()

def validate_graph():
 g=(ROOT/'WorkspaceSource/locomotion.agf').read_text();agr=(ROOT/'WorkspaceSource/player_main.agr').read_text()
 # Every custom graph identifier must exist in the packed control template.
 declared=set(re.findall(r'AnimSrcGCTVar\w+ (\w+)\s*\{',agr))
 expressions=re.findall(r'(?m)^\s*(?:Expression|Condition|StartCondition|InterruptExpr|BlendWeight|Weight\w+|Weapon\w+|Value[XY]) "(.*)"',g)
 referenced=set(re.findall(r'\bMLADSLean\w+\b',' '.join(expressions)))
 assert referenced <= declared, 'Undeclared graph controls: '+str(referenced-declared)
 for arg in re.findall(r'HasVariableChanged\(\s*([^,)\n]+)',g):
  assert re.fullmatch(r'[A-Za-z_]\w*',arg.strip()) and arg.strip() in declared, 'HasVariableChanged requires a variable: '+arg
 for name in ['MLADSLeanGate','MLADSLeanCanary','MLADSLeanAmount']:
  assert agr.count('AnimSrcGCTVarFloat '+name+' ')==1
  body=re.search(r'AnimSrcGCTVarFloat '+name+r'\s*\{([^{}]*)\}',agr)[1]
  lines=[line.strip() for line in body.splitlines() if line.strip()]
  assert len(lines)==3 and all(re.fullmatch(r'(DefaultValue|MinValue|MaxValue) -?[0-9.]+',line) for line in lines)
 coverage=json.loads((ROOT/'Mode-Coverage.json').read_text())
 assert set(coverage)=={'StandIdle','StandWalk','CrouchIdle','CrouchWalk'}
 for mode,entry in coverage.items():
  for suffix in ['Left','Right']:
   name=entry['native_chain']+suffix
   expression=re.search(r'AnimSrcNodeProcTransform '+name+r'\s*\{.*?Expression "([^"]+)"',g,re.S)[1]
   assert '*(1.0-MLADSLeanGate)' in expression
  if mode!='StandIdle':assert not any(any(x in n for x in ['Leg','Foot','Toe','HipExtra']) for n in entry['bones'])
  if mode.startswith('Crouch'):assert 'Pelvis' not in entry['bones']
 assert 'WeaponRoll "8.0*MLADSLeanAmount*MLADSLeanGate"' in g
 head_direction=json.loads((ROOT/'Head-Direction-v16.json').read_text())
 assert len(head_direction['changed_nodes'])==4
 for change in head_direction['changed_nodes']:
  assert change['new_graph_amount'] == -change['old_graph_amount']
 revision=json.loads((ROOT/'Pose-Revision-v14.json').read_text())
 assert revision['head']['pitch_forward_degrees']==5 and revision['head']['extra_counter_roll_degrees']==0
 assert g.count('AnimSrcNodeProcTransform ML15_HeadForwardNod {')==1
 assert 'ML14_HeadCounterRoll' not in g
 assert '*(1.0-clamp(MovementSpeed, 0.0, 1.0))' in g
 spec=json.loads((ROOT/'Pose-Spec.json').read_text());assert max(spec['math_reconstruction_error'].values())<1e-5
 symmetry=json.loads((ROOT/'Symmetry-Measurements.json').read_text())
 assert max(v['symmetry_error_m'] for v in symmetry['authoring_model_offsets'].values())<1e-5
 return {'pose_math_reconstruction_max_error':spec['math_reconstruction_error'],'corrected_bones_per_direction':{k:len(v) for k,v in spec['corrections'].items()},'mode_coverage':coverage,'authoring_symmetry_max_error_m':max(v['symmetry_error_m'] for v in symmetry['authoring_model_offsets'].values()),'shared_weapon_roll_target':'signed 8-degree target via one final NormalWeaponIK roll expression; native interpretation/alignment pending','npc':'native locomotion between +/-2m endpoints; private demo graph control selects shared raised ADS branches; graph blend warmup 0.4s; native playback not run here','native_compilation_and_playback':'V16 NOT RUN: requires user Windows DayZDiag. Native exposure balance, weapon roll, gait, crouch and NPC behavior remain pending.'}

def main():
 checks=validate_graph()
 hashes={}
 for src,prefix,path in [('LogicSource','MLADSLeanLogic','@MLADSLeanLogic/Addons/MLADSLeanLogic.pbo'),('WorkspaceSource','DZ\\anims\\workspaces\\player\\player_main','@MLADSLeanWorkspace/Addons/MLADSLeanWorkspace.pbo')]:hashes[path]=build(ROOT/src,prefix,ROOT/path)
 checks.update({'pbo_sha256':hashes,'pbo_headers_prefix_offsets_source_and_sha1':'passed: independently parsed and compared to every input file','official_script_revision':'e8204c69fcfd056ea29a9728990fd9f7941ce8a6','script_API_review':'Native movement overrides, weapon SetADS, graph writes and lifecycle methods checked against official 1.30 scripts; native compilation pending','changed_native_files':['locomotion.agf','player_main.agr'],'source_directory':'F:/DayZProjects','revision':'v16 reverse existing left Head Z roll in all four shared pose branches; remaining pose/controller unchanged','dependencies':'Vanilla Mosin only; no SNAFU or old MovementLab packages.'})
 (ROOT/'validation.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(json.dumps(checks,indent=2))
if __name__=='__main__':main()
