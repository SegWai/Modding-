MOVEMENTLAB SHARED STANDING LEAN EDITOR v1

Close DayZ, start Steam, and open Launch-Shared-Standing-Lean.cmd. Both
characters spawn in black combat boots with AK74 rifles and fitted rifle
attachments. The native models may show underwear.

Stand upright, raise the rifle, then open F6 for weapon/arm/head controls
or F7 for XYZ translation and rotation of 60 joints. Choose LEFT or RIGHT.
The NPC and your own standing raised player read the same live pose data.
Change a value while watching the NPC and it is applied to both actors
without saving or reloading. Native aiming, arm calibration and differences
in actor state can affect the rendered result. Start with centred aim.

Press X while standing with the rifle fully raised to hold the preview.
It holds your movement speed at zero, keeps the rifle raised and uses the
editor's selected lean side on both actors. The animation graph keeps
evaluating, so you can switch sides and edit values live. Native idle and
aim can still move. Press X again to release. Leaving the standing state
or switching the held item also releases the hold. Closing the panel
while frozen lets you change camera view and inspect the held pose.

Outside the editor or X hold, use your normal Q/E keys for standing lean.
Walking and jogging use native locomotion. The comparison NPC stays in
place. The two future walk/jog JSON seeds are byte-identical copies of the
starting standing bank and are unused during playback. Use your latest
standing save as the source when authoring those gaits in a future build.

Save all in either panel saves both sides to
Profiles/SharedStandingLean/MLSharedStandingLeanPreset.json. This test
starts with the approved standing values and zero offsets for extra joints.
Direct joint edits can move hands away from the rifle. Use F6 for grip
constrained adjustments and small F7 changes for individual joints.

Launch-Shared-Standing-Lean.cmd -CheckOnly verifies executable, mission
and package checksums. Native compilation, UI focus, mirroring, preview
hold and FPS still need an in-game check. Collect-Logs.cmd collects the
test's logs and its separate authored preset.
