DAYZ FPS HELPER - Windows batch file

1. Close DayZ.
2. Double-click DayZ_FPS_Helper.bat. Administrator access is not needed.
3. Choose 1 to apply the preset. Press Enter to use normal Documents\DayZ settings.
   If using a MovementLab launcher, also enter its Profiles\MovementLogic folder.
4. Read the changes printed by the helper, then launch DayZ normally.
5. To undo, close DayZ, run the helper, choose 2 and select the original backup.

Backups: %LOCALAPPDATA%\DayZ_FPS_Helper\Backups
Backups are small settings files. They are not automatically deleted.
Apply is repeatable: already-lower settings are kept, and unchanged files are not backed up again.

WHAT IT DOES
Only edits numeric settings already present in .cfg and .DayZProfile files directly
inside the selected profile folders. Never adds unsupported keys.
Caps sceneComplexity at 200000, shadowZDistance at 100, viewDistance at 1600,
preferredObjectViewDistance at 1000; increases terrainGrid to at least 25.
Turns FSAA, AToC, SSAO and VSync off only when those settings exist and are enabled.
Original encoding, BOM, line endings, resolution, controls and unrelated settings are preserved.
All originals are backed up before writing. Failed writes trigger an attempted rollback.
Restore verifies backup SHA-256 hashes before restoring settings.

LIMITATIONS AND VISUAL TRADEOFFS
A large FPS boost or stable FPS while aiming at trees is not guaranteed.
Some modern DayZ settings may be stored under different keys; the helper reports
when nothing matched instead of inserting old settings. A server can override draw distances.
Lower detail can cause pop-in, simpler terrain/shadows and jagged foliage. VSync off can cause tearing.
It does not remove vegetation, change game PBOs, disable anti-cheat, tweak the registry,
stop services, clear caches, change CPU affinity or add questionable launch flags.

IN-GAME CHECKS STILL NEEDED
In Video settings, where available, turn Hardware Antialiasing and Alpha to Coverage off,
set Ambient Occlusion off, and try Shadows low. Start with Objects and Terrain low.
Keep your native resolution initially. Save and compare FPS in the same location,
with the same scope, aimed at the same trees. Adjust these through the game's UI
if the helper did not find equivalent settings in your version.
If the drop occurs only through a magnified scope, this preset may not remove it.

VALIDATION
The batch wrapper and embedded PowerShell were reviewed and syntax checked.
This environment is Linux: running DayZ and measuring FPS on Windows were not possible.
