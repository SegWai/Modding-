MOVEMENTLAB SHARED STANDING POSE MATCH v2

Start Steam, close DayZ, then open Launch-Shared-Standing-Match.cmd.
Raise the AK74 while standing and use Q/E, or press X and choose a side
in F6/F7. Hold your aim forward and level for about two seconds.

F6/F7 still edit the full shared standing preset. The automatic match
samples the NPC's 20 upper-body reference joints, including the neck,
head and hands. Foot and toe sampling is outside this matching pass.
The public ZIP ships with the approved default seed. To use a prior
save, copy MLSharedStandingLeanPreset.json to Profiles/SharedStandingMatchV2
before launching. The local build already carries the crash-session save.

The custom graph exits before native processing when movement is requested
and re-enters after at least 0.25 seconds of settled idle. Walking and
jogging use native locomotion. The first native retest should repeat right
lean, Shift plus movement, and the return to idle with the rifle raised.

The prior log recorded the crash after jog-to-idle. The engine fault is
unidentified. It also recorded a missing RightFoot reference and no active
pose match. The guard and narrower capture address these observed paths.
Native compile, Shift stability and visible pose matching remain untested.
Collect-Logs.cmd captures [MLMATCH] readbacks and any crash log locally.
